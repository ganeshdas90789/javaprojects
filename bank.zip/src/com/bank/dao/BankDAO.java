package com.bank.dao;

import java.util.Scanner;

import com.bank.pojo.BankAccount;

public class BankDAO {
	
	private BankAccount bankarr[];
	Scanner Sc;
	
	public BankDAO()
	{
		Sc=new Scanner(System.in);
	}
	
	public void insert()
	{
	
		System.out.println("Enter number of depositors:");
		int noofdepositors=Sc.nextInt();
		bankarr=new BankAccount[noofdepositors];
		for(int i=0;i<bankarr.length;i++)
		{
			bankarr[i]=new BankAccount();
			
			System.out.println("Enter the Account number:");
			bankarr[i].setAccountno(Sc.nextInt());
			
			System.out.println("Enter the name of depositor:");
			bankarr[i].setDepositorName(Sc.next());

			System.out.println("Enter the address of depositor:");
			bankarr[i].setAddressofDepositor(Sc.next());
			

			System.out.println("Enter the type of Account :");
			bankarr[i].setTypeOfAccount(Sc.next());
			

			System.out.println("Enter the balance:");
			bankarr[i].setBalance(Sc.nextDouble());
			
			
			
		}
	}
	public void display()
	{
		for(BankAccount a:bankarr)
		{
			if(a!=null)
			{
				System.out.println(" Account Number: " + " " + a.getAccountno());
				
				System.out.println("Depositor name  :" + " " + a.getDepositorName());
				
				System.out.println("Depositor Address :" + " " + a.getAddressofDepositor());
				
				System.out.println(" Type of Account  :" + " " + a.getTypeOfAccount());
				
				System.out.println(" Balance is :" + " " + a.getBalance());
			}
		}
	}
	//add money to any depositor
	
	public void deposite()
	{
		System.out.println("Enter the account number u want to add money:");
		int accountNo=Sc.nextInt();
		System.out.println("Enter the amount you have to add:");
		int add=Sc.nextInt();
		for(BankAccount a:bankarr)
		{
		if(a.getAccountno()==accountNo)
		{
			a.setBalance( a.getBalance()+add);
			
		}
		
		}
		
		
	}
	//money withdraw from account.
	
	public void withdraw()
	{
		System.out.println("Enter the account number u want to withdraw money:");
		int accountNo=Sc.nextInt();
		System.out.println("Enter the amount you have to withdraw:");
		int withdraw=Sc.nextInt();
		for(BankAccount a:bankarr)
		{
		if(a.getAccountno()==accountNo)
		{
			a.setBalance( a.getBalance()-withdraw);
			
		}
		
		}
		
		
	}
	//change address
	public void changeaddress()
	{
			System.out.println("Enter the account number u want to change address:");
			int accountNo=Sc.nextInt();
			System.out.println("Enter the new address you have to add:");
			String add=Sc.next();
			for(BankAccount a:bankarr)
			{
			if(a.getAccountno()==accountNo)
			{
			 a.setAddressofDepositor(add);
				
			}
			
			}
			
			
	
	}
	//no. of transactions
	public void transaction()
	{
		
		
	}
	
	

}
