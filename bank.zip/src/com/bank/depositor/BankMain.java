package com.bank.depositor;

import com.bank.menu.BankMenu;

public class BankMain {

	public static void main(String args[])
	{
		
     BankMenu m1=new BankMenu();
     m1.displaybank();
}
     
	

}
