package com.bank.menu;

import java.util.Scanner;

import com.bank.service.DepositorService;
public class BankMenu {
	Scanner Sc;
	DepositorService depservice;
	
	public BankMenu()
	{
		depservice=new DepositorService();
	}
	
	public void displaybank()
	{
		Sc=new Scanner(System.in);
		String choice="Y";
		int ch=0;
		
		while(choice.equals("Y"))
		{
			System.out.println("Enter your choice:");
			System.out.println("1. inesrt Depositor Details:");
			System.out.println("2. show deposited amount.");
			System.out.println("3. show withdraw amout.");
			System.out.println("4. Change Address.");
			System.out.println("5. view details.");
			System.out.println("6. No.of transactions.");
			System.out.println("7. Exit");
			ch=Sc.nextInt();
			

			switch(ch)
			{
			case 1:
				depservice.insertbankdetails();
				
				break;
			case 2:
				
				depservice.updatedetails();
				break;
			case 3:
				
				depservice.updatedetails2();
				break;
			case 4:
				 depservice.updatedetails3();
				break;
				
			case 5:
				depservice.showdetails();
			
				break;
			case 6:
				break;
			
			case 7:
				
				System.exit(0);
			}
			
		
			System.out.println("Do you want to continue(Y/N):");
			
			choice=Sc.next();
		}
	
	}

}
	
